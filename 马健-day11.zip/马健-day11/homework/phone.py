
class OldPhone:
    __brand = None

    def setbrand(self,brand):
        self.__brand = brand
    def getbrand(self):
        return self.__brand

    def call(self,number):
        print("正在给：",number,"拨号...")

class NewPhone(OldPhone):
    def call(self,number):
        print("语音拨号中。。。")
        super().call(number)
        print(super().getbrand(),"品牌的手机很好用！")


phone1 = OldPhone()
phone2 = NewPhone()
phone1.call("123")
phone2.setbrand("iPhone 12")
phone2.call("123")





class Cooker:
    __name = None
    __age = None

    def setname(self,name):
        self.__name = name

    def getname(self):
        return self.__name

    def setage(self,age):
        self.__age = age
    def getage(self,):
        return self.__age

    def cook(self):
        print("这个厨师不会做饭！")


class Cookers(Cooker):
    def cooks(self):
        print("姓名为：",super().getname())



class Cookerss(Cookers):
    def cookss(self):
        print("姓名为：",super().getname(),"，年龄为：",super().getage())
        super().cook()


cooks = Cookerss()
cooks.setname("张三")
cooks.setage("18")
print(cooks.getname())
print(cooks.getage())
cooks.cookss()





















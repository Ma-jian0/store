
import  unittest
from  jisuanqi.celc import Calculator

class TestCalc1(unittest.TestCase):

    def testsubraction(self):
        c = Calculator()
        a = 10
        b = 5
        s = 5
        sum = c.subtraction(a,b)
        self.assertEquals(s,sum)

    def testsubraction1(self):
        c = Calculator()
        a = 10
        b = -5
        s = 15
        sum = c.subtraction(a, b)
        self.assertEquals(s, sum)

    def testsubraction2(self):
        c = Calculator()
        a = -10
        b = -5
        s = -5
        sum = c.subtraction(a, b)
        self.assertEquals(s, sum)

    def testsubraction4(self):
        c = Calculator()
        a = -10
        b = 5
        s = -15
        sum = c.subtraction(a, b)
        self.assertEquals(s, sum)


import  unittest
from  jisuanqi.celc import Calculator

class TestCalc13(unittest.TestCase):

    def testdivision(self):
        c = Calculator()
        a = 15
        b = 5
        s = 3
        sum = c.division(a,b)
        self.assertEquals(s,sum)

    def testdivision1(self):
        c = Calculator()
        a = -15
        b = 5
        s = -3
        sum = c.division(a, b)
        self.assertEquals(s, sum)

    def testdivision2(self):
        c = Calculator()
        a = -15
        b = -5
        s = 3
        sum = c.division(a, b)
        self.assertEquals(s, sum)

    def testdivision3(self):
        c = Calculator()
        a = 15
        b = -5
        s = -3
        sum = c.division(a, b)
        self.assertEquals(s, sum)

class Calculator:
    def add(self,a,b):
        return  a+ b

    def subtraction(self,a,b):
        return a - b

    def multiplication(self,a,b):
        return  a * b

    def division(self,a,b):
        return a / b











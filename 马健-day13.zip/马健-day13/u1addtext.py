
import unittest
import os
from HTMLTestRunner import HTMLTestRunner
from jisuanqi.subtractionText import TestCalc1
from jisuanqi.addText import TestCalc
from jisuanqi.multiplicationText import TestCalc12
from jisuanqi.divisionText import TestCalc13

suits =unittest.TestSuite()  #获得一个测试集

tests =unittest.defaultTestLoader.discover(os.getcwd(),"*Text.py")
suits.addTest(tests)


f = open("计算机测试报告.html","w+",encoding="utf-8")
runner = HTMLTestRunner.HTMLTestRunner(
    stream = f, # 将报告写到那个文件流
    verbosity=1, # 报告的详细程度
    title="计算器的测试报告"
)

runner.run(suits)





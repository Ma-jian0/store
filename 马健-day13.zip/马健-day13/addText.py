
import  unittest
from  jisuanqi.celc import Calculator

class TestCalc(unittest.TestCase):

    def testadd(self):
        c = Calculator()
        a = 6
        b = 7
        s = 13
        sum = c.add(a, b)
        self.assertEquals(s,sum)

    def testadd1(self):
        c = Calculator()
        a = -6
        b = -7
        s = -13
        sum = c.add(a, b)
        self.assertEquals(s, sum)

    def testadd2(self):
        c = Calculator()
        a = 6
        b = -7
        s = -1
        sum = c.add(a, b)
        self.assertEquals(s, sum)

    def testadd3(self):
        c = Calculator()
        a = -6
        b = 7
        s = 1
        sum = c.add(a, b)
        self.assertEquals(s, sum)





import  unittest
from  jisuanqi.celc import Calculator

class TestCalc12(unittest.TestCase):

    def testmultiplication(self):
        c = Calculator()
        a = 3
        b = 5
        s = 15
        sum = c.multiplication(a,b)
        self.assertEquals(s,sum)

    def testmultiplication1(self):
        c = Calculator()
        a = -3
        b = 5
        s = -15
        sum = c.multiplication(a,b)
        self.assertEquals(s,sum)

    def testmultiplication2(self):
        c = Calculator()
        a = 3
        b = -5
        s = -15
        sum = c.multiplication(a,b)
        self.assertEquals(s,sum)


    def testmultiplication3(self):
        c = Calculator()
        a = -3
        b = -5
        s = 15
        sum = c.multiplication(a,b)
        self.assertEquals(s,sum)

num = [21,21,21,56,56,56,56,56,56,56,56,56,10,10,10]
nums = {}

def number(num):
    for i,j in enumerate(num):
        if j in num[0:i]:
            continue
        number = num.count(j)
        nums[j] = number
number(num)
print(nums)









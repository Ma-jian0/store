from homework2 import computer

c = computer()

c.setsize(21)
c.setcpu("i9")
c.setpay(5000)
c.settime("5")
c.setmemory(8)

c.play("LOL")
c.type()
c.watch("快乐大本营")






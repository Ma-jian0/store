from homework1 import cup

c = cup()

c.sethigh(5)

c.setvolume(10)

c.setcolor("白色")

c.settexture("玻璃")

c.liquor("果汁")






class computer:
    __size = 0
    __pay = 0
    __cpu = ""
    __memory = ""  #内存
    __time = 0

    def setsize(self,size):
        if size < 0 :
            print("请输入合法尺寸！")
        else:
            self.__size = size

    def getsize(self):
        return self.__size

    def setpay(self,pay):
        if pay<0 :
            print("请输入合法价格！")
        else:
            self.__pay = pay

    def getpay(self):
        return  self.__pay

    def setcpu(self,cpu):
        self.__cpu = cpu

    def getcpu(self):
        return self.__cpu

    def setmemory(self,memory):
        self.__memory = memory

    def getmemory(self):
        return self.__memory

    def settime(self,time):
        self.__time = time
    def gettime(self):
        return self.__time


    def type(self):
        print("这台电脑可以打字",self.__time,"时间")

    def play(self,plays):
        print("这台电脑可以玩",plays,"游戏")

    def watch(self,TV):
        print("这台电脑可以看",TV,"视频")
class cup:
    __hight = ""
    __volume = ""
    __color = ""
    __texture = ""

    def sethigh(self,high):
        if high < 0 :
            print("输入高度不合法！")
        else:
            self.__hight = high

    def gethigh(self):
        return self.__hight


    def setvolume(self,volume):
        if volume < 0 and volume > self.__hight:
            print("输入容积不合法！")
        else:
            self.__volume = volume

    def getvolume(self):
        return self.__volume


    def setcolor(self,color):
        self.__color = color
    def getcolor(self):
        return self.__color

    def settexture(self,texture):
        self.__texture = texture
    def gettexture(self):
        return self.__texture

    def liquor(self,liquor):
        print("这个高度为",self.__hight,",容积为：",self.__volume,"的杯子可以装",liquor)






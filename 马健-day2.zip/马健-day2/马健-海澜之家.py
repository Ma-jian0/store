'''
print("----------------------------------------------------海澜之家---------------------------------------------------------------")
print("=========================================================================================================================")
print("类型             名称              尺码              材质             颜色             价格               购买数量          备注")
print("羽绒服       男士连帽羽绒服       M/L/XL/XXL         聚酯纤维        黑色/卡其色          798￥                30         冬季爆款")
print("冲锋衣       男士花纹冲锋衣       M/L/XL/XXL         聚酯纤维        黑色/蓝色/墨绿色      658￥                20         青春休闲")
print("针织衫       男士纯色针织衫       M/L/XL             毛加腈纶        米色/深蓝/浅灰        99￥                 50         基础大众")
print("衬衫        男士纯棉休闲衬衫      L/XL/XXL         再生纤维素纤维       藏青色             289￥                50         商务休闲")
print("卫衣         儿童童趣套头衫      S/M/L/XL/XXL         纯棉          中黄/大红            98￥                 10         青春流行")
print("卫衣         男士保暖套头衫      M/L/XL/XXL/3XL      聚酯纤维           黑色             238￥                100        时尚都市")
print("休闲裤       男士经典休闲裤       L/XL/XXL/3XL        纯棉            纯黑色             139￥                100        基础大众")
print("--------------------------------------------------------------------------------------------------------------------------")
print("合计：",(798*30+658*20+99*50+289*50+98*10+238*100+139*100),"￥")

'''
info='''
----------------------------------------------------海澜之家---------------------------------------------------------------
=========================================================================================================================
类型\t\t名称\t\t尺码\t\t材质\t\t颜色\t\t价格\t\t购买数量\t\t备注
{type}\t\t{name}\t\t{size}\t\t{texture}\t\t{colour}\t\t{pay}\t\t{number}\t\t{remark}
{type01}\t\t{name01}\t\t{size01}\t\t{texture01}\t\t{colour01}\t\t{pay01}\t\t{number01}\t\t{remark01}
{type02}\t\t{name02}\t\t{size02}\t\t{texture02}\t\t{colour02}\t\t{pay02}\t\t{number02}\t\t{remark02}
{type03}\t\t{name03}\t\t{size03}\t\t{texture03}\t\t{colour03}\t\t{pay03}\t\t{number03}\t\t{remark03}
{type04}\t\t{name04}\t\t{size04}\t\t{texture04}\t\t{colour04}\t\t{pay04}\t\t{number04}\t\t{remark04}
{type05}\t\t{name05}\t\t{size05}\t\t{texture05}\t\t{colour05}\t\t{pay05}\t\t{number05}\t\t{remark05}
{type06}\t\t{name06}\t\t{size06}\t\t{texture06}\t\t{colour06}\t\t{pay06}\t\t{number06}\t\t{remark06}
--------------------------------------------------------------------------------------------------------------------------
合计:{pay0}￥
'''

type1 = "羽绒服"
name1 = "男士连帽羽绒服"
size1 = "M/L/XL/XX"
texture1 = "聚酯纤维"
colour1 = "黑色/卡其色"
pay1 = 798
number1 = 30
remark1 = "冬季爆款"

type2 = "冲锋衣"
name2 = "男士花纹冲锋衣"
size2 = "M/L/XL/XX"
texture2 = "聚酯纤维"
colour2 = "黑色/蓝色/墨绿色"
pay2 = 658
number2 = 20
remark2 = "青春休闲"

type3 = "针织衫"
name3 = "男士纯色针织衫"
size3 = "M/L/XL"
texture3 = "毛加腈纶"
colour3 = "米色/深蓝/浅灰"
pay3 = 99
number3 = 50
remark3 = "基础大众"

type4 = "衬衫"
name4 = "男士纯棉休闲衬衫"
size4 = "L/XL/XXL"
texture4 = "再生纤维素纤维"
colour4 = "藏青色"
pay4 = 289
number4 = 50
remark4 = "商务休闲"

type5 = "卫衣"
name5 = "儿童童趣套头衫"
size5 = "S/M/L/XL/XXL"
texture5 = "纯棉"
colour5 = "中黄/大红"
pay5 = 98
number5 = 10
remark5 = "青春流行"

type6 = "卫衣"
name6= "男士保暖套头衫"
size6 = "M/L/XL/XXL/3XL"
texture6 = "聚酯纤维"
colour6 = "黑色"
pay6 = 238
number6 = 100
remark6 = "时尚都市"

type7 = "休闲裤"
name7= "男士经典休闲裤"
size7 = "L/XL/XXL/3XL"
texture7 = "纯棉"
colour7 = "黑色"
pay7 = 139
number7 = 100
remark7 = "基础大众"

print(info.format(type=type1,name=name1,size=size1,texture=texture1,colour=colour1,pay=pay1,number=number1,remark=remark1,
                  type01=type2,name01=name2,size01=size2,texture01=texture2,colour01=colour2,pay01=pay2,number01=number2,remark01=remark2,
                  type02=type3,name02=name3,size02=size3,texture02=texture3,colour02=colour3,pay02=pay3,number02=number3,remark02=remark3,
                  type03=type4,name03=name4,size03=size4,texture03=texture4,colour03=colour4,pay03=pay4,number03=number4,remark03=remark4,
                  type04=type5,name04=name5,size04=size5,texture04=texture5,colour04=colour5,pay04=pay5,number04=number5,remark04=remark5,
                  type05=type6,name05=name6,size05=size6,texture05=texture6,colour05=colour6,pay05=pay6,number05=number6,remark05=remark6,
                  type06=type7,name06=name7,size06=size7,texture06=texture7,colour06=colour7,pay06=pay7,number06=number7,remark06=remark7,
                  pay0=pay1*number1+pay2*number2+pay3*number3+pay4*number4+pay5*number5+pay6*number6+pay7*number7))









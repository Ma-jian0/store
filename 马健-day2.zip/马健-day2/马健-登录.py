


a = input("请输入用户名：")
b = input("请输入密码：")
c = "jason"
d = "admin"
i=0
while i<3:
    i=i+1
if a==c and b == d:
    print("登陆成功！")
else:
    print("用户名和密码错误！")


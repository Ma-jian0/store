# import random
#
# a = int (random.random()  *100  )
# i  =0
# while  True:
#     b=int(input("请输入您猜的数："))
#     i=i+1
#     if b<a:
#         print("小了！")
#     elif  b>a:
#         print("大了！")
#     else:
#         print("恭喜你猜中了！","本次随机数为",a,",本次一共猜了",i,"次")


# i=0
# x=0
# while True:
#     a=int(input("请输入10个数"))
#     i=i+1
#     if i<=10: x=x+a
#     else:
#         print("输入的10个数和为：",x)
#         break

# a = input("请输入姓名：")
# b = int (input("请输入身份证号："))
# c = int (input("请输入年龄："))
# d = input("请输入性别：")
# e = int (input("请输入身高："))
# f = int (input("请输入体重："))
#
# info='''
# {name}\t\t{number}\t\t{age}\t\t{sex}\t\t{high}\t\t{weight}
# '''
#
# print("姓名\t\t身份证号\t\t\t\t\t\t年龄\t\t性别\t\t身高\t\t体重")
# print(info.format(name=a,number=b,age=c,sex=d,high=e,weight=f))



# stu1 = 45
# stu2 = 23
# print(stu1+stu2)

# num1=1
# num2=2
# num3=3
# print(num1+num2+num3)

# num1 =45
# num2 = num1
# print(num2)

# a=int(input("请输入年龄："))
# if a>=18:
#     print("可以去看电影！")
# else:
#     print("年龄不合法！")





# a = 56
# b = 78
# c=a-b
# b=a
# a=a-c
# print("a=",a,"b=",b)



# import random
#
# print(int(random.random()*100+50))

# i = 0
# a = 0
# b = 0
# c = 0
#
# while i<3:
#     d=int(input("请输入三角形的三条边长"))
#     i=i+1
#     if a==0 and b==0 and c==0:
#         a=int(d)
#     elif a>0 and b==0 and c == 0:
#         b=int(d)
#     else:
#         c=int(d)
# if a+b>c and a+c>b and b+c>a:
#         if a==b and a==c and b==c:
#             print("该三角形为等边三角形！")
#         elif a==b and a!=c and b!=c:
#             print("该三角形为等腰三角形！")
#         elif a==c and a!=b and b!=c:
#             print("该三角形为等腰三角形！")
#         elif b == c and a != b and a != c:
#             print("该三角形为等腰三角形！")
#         else:
#             print("该三角形为普通三角形")
# else:
#     print("无法构成三角形！")
# print(a,b,c)







